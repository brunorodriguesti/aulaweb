package org.example;

//Classe
public class Jogador {
    //Atributos
    private String nome;
    protected Integer idade;
    private String posicao;
    private Integer pontucao;


    public Jogador() {
        if(idade != null){

        }
    }

    public Jogador(String nome, int idade, String posicao, int pontucao) {
        this.nome = nome;
        this.idade = idade;
        this.posicao = posicao;
        this.pontucao = pontucao;
    }

    //método que não retorna valor usa o void
    public void adicionarPonto(int pontuacao) {
        this.pontucao = this.pontucao + pontuacao;
    }

    // método que retorna valor
    public int obterPontuacao(){
        return pontucao;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        if(nome != null) {
            this.nome = nome;
        }else {
            System.out.println("Nome não pode ser nulo");
        }
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String getPosicao() {
        return posicao;
    }

    private void setPosicao(String posicao) {
        this.posicao = posicao;
    }
}
