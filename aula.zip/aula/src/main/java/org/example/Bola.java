package org.example;

public class Bola {
    private String cor;
    protected int tamanho;

    public Bola(String cor, int tamanho) {
        this.cor = cor;
        this.tamanho = tamanho;
    }

    public void mostrar(){
        System.out.println("Cor " + this.cor);
        System.out.println("Tamanho " + this.tamanho);
    }

    public void mostrar(String marca){
        System.out.println("A marca da bola eh: " + marca);
    }
    public void mostrar(Integer libras, String detalhe){
        System.out.println("Libras " + libras + " detalhe " + detalhe);
    }
}
