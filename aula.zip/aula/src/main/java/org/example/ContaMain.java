package org.example;

public class ContaMain {
    public static void main(String[] args) {

        //Instanciando um objeto
        ContaBancaria contaBancaria1 = new ContaBancaria(12, "Beltrano", 100);
        ContaBancaria contaBancaria2 = new ContaBancaria(123, "Fuluno", 2000);
        ContaBancaria contaBancaria3 = new ContaBancaria(456, "Cicrano", -100);

        contaBancaria1.setSaldo(900);


        contaBancaria1.depositar(1000);
        contaBancaria2.depositar(900);
        contaBancaria3.depositar(200);

        System.out.println("" +
                "O saldo da conta  " + contaBancaria1.getNumero()
                + " do cliente " + contaBancaria1.getCliente()
                + " tem saldo " +
                + contaBancaria1.consultar());

        System.out.println("" +
                "O saldo da conta  " + contaBancaria2.getNumero()
                + " do cliente " + contaBancaria2.getCliente()
                + " tem saldo " +
                + contaBancaria2.consultar());

        System.out.println("" +
                "O saldo da conta  " + contaBancaria3.getNumero()
                + " do cliente " + contaBancaria3.getCliente()
                + " tem saldo " +
                + contaBancaria3.consultar());
    }
}
