package org.example;

public class Util {

    public static void validarIdade(Integer idade){
        if(idade == null || idade < 0){
            System.out.println("Idade inválida");
        }
    }
}
