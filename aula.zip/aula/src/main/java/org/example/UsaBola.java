package org.example;

public class UsaBola {
    public static void main(String[] args) {
        Bola bola = new Bola("Amarela", 14);
        BolaFutebol bolaFutebol = new BolaFutebol(
                "Branca", 20, "Society");
        BolaVolei bolaVolei = new BolaVolei("Azul", 13, 15);

        //bola.mostrar();
        //bolaFutebol.mostrar();
        bolaVolei.mostrar();
        bolaVolei.mostrar("Penault");
    }
}
