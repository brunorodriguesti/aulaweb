package org.example;

public class BolaFutebol extends Bola{

    private String tipo;

    public BolaFutebol(String cor, int tamanho, String tipo) {
        super(cor, tamanho);
        this.tipo = tipo;

    }

    @Override
    public void mostrar(){
        //super.mostrar();
        System.out.println("Tipo " + this.tipo);
    }
    @Override
    public void mostrar(String outraMarca){
        System.out.println("aqui");
    }


}
