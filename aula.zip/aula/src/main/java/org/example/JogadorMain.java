package org.example;

public class JogadorMain {
    public static void main(String[] args) {
        //objeto
        Jogador jogador1 = new Jogador("Fonseca", 21, "Tenista", 20);
        Util.validarIdade(jogador1.idade);
        /*
        jogador1.setNome("Fonseca");
        jogador1.setIdade(21);
        jogador1.setPosicao("Tenista");
        */
        jogador1.adicionarPonto(10);
        jogador1.adicionarPonto(20);


        System.out.println("Nome do jogador " + jogador1.getNome());
        System.out.println("Idade do jogador " + jogador1.getIdade());
        System.out.println("Posicao do jogador " + jogador1.getPosicao());
        System.out.println("Pontuacao do jogador " + jogador1.obterPontuacao());

    }
}
