package org.example;

public class BolaVolei extends Bola{

    private Integer circunferencia;

    public BolaVolei(String cor, int tamanho, Integer circunferencia) {
        super(cor, tamanho);
        this.circunferencia = circunferencia;
    }

    @Override
    public void mostrar() {
        super.mostrar();
        System.out.println("Circuferencia " + circunferencia);
    }
}
