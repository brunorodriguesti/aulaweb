package org.example;

public class Caminhao extends Veiculo{

    private  String tipoCarga;

    public Caminhao() {
        super();
    }

    public void insereModelo(String modelo){
        this.modelo = modelo;
    }

    public void cadastraPlaca(String placa){
        this.placa = placa;
    }
    public void cadastraTipoCarga(String tipoCarga){
        this.tipoCarga = tipoCarga;
    }
}
