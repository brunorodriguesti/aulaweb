package org.example;

public class TransportadoraMain {
    Caminhao caminhao = new Caminhao();

}
