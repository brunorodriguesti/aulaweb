package org.pessoa;

public class Funcionario extends PessoaFisica{
    private String cartao;

    public String getCartao() {
        return cartao;
    }

    public void setCartao(String cartao) {
        this.cartao = cartao;
    }

    public void mostraClasse(){
        setCartao("2434");
        System.out.println("Classe Funcionário");
        System.out.println("O cartao " + getCartao());
    }
}
